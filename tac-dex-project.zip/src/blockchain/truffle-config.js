const HDWalletProvider = require("@truffle/hdwallet-provider");
require("dotenv").config();

module.exports = {
    networks: {
        tac: {
            provider: () => new HDWalletProvider(process.env.PRIVATE_KEY, "https://turin.rpc.tac.build"),
            network_id: 2390,
            gas: 5500000,
            confirmations: 2,
            timeoutBlocks: 200,
            skipDryRun: true,
        },
    },
    compilers: {
        solc: {
            version: "0.8.0",
        },
    },
};
