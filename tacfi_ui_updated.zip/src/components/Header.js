
import React from "react";

export default function Header() {
  return (
    <header className="w-full p-4 flex justify-between items-center bg-card">
      <h1 className="text-lg font-bold">TacFi</h1>
      <button className="px-4 py-2 bg-primary rounded hidden md:block">Connect Wallet</button>
      <button className="p-2 bg-primary rounded md:hidden">
        🏦
      </button>
    </header>
  );
}
