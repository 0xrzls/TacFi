import React, { useState } from "react";
import { ethers } from "ethers";

const WalletConnect = () => {
  const [walletAddress, setWalletAddress] = useState("");

  const connectWallet = async () => {
    if (window.ethereum) {
      try {
        const provider = new ethers.providers.Web3Provider(window.ethereum);
        await window.ethereum.request({ method: "eth_requestAccounts" });
        const signer = provider.getSigner();
        setWalletAddress(await signer.getAddress());
      } catch (error) {
        console.error("Error connecting to wallet", error);
      }
    } else {
      alert("MetaMask not detected");
    }
  };

  return (
    <button 
      onClick={connectWallet} 
      className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
    >
      {walletAddress ? walletAddress.slice(0, 6) + "..." + walletAddress.slice(-4) : "Connect Wallet"}
    </button>
  );
};

export default WalletConnect;