import React, { useState } from "react";
import { AiOutlineSwap } from "react-icons/ai";

const Swap = () => {
  const [inputToken, setInputToken] = useState("");
  const [outputToken, setOutputToken] = useState("");

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-[#141E30] to-[#243B55] p-4">
      <div className="bg-white/10 backdrop-blur-xl p-6 rounded-xl shadow-lg w-full max-w-md border border-white/20">
        <h2 className="text-xl font-semibold text-center text-white mb-4">
          Swap Tokens
        </h2>

        <div className="bg-gray-900 p-4 rounded-lg mb-3">
          <label className="text-sm text-gray-400">From:</label>
          <input
            type="number"
            className="w-full bg-transparent text-white text-lg font-semibold focus:outline-none"
            placeholder="0.0"
            value={inputToken}
            onChange={(e) => setInputToken(e.target.value)}
          />
        </div>

        <div className="flex justify-center my-2">
          <AiOutlineSwap className="text-white text-3xl cursor-pointer" />
        </div>

        <div className="bg-gray-900 p-4 rounded-lg">
          <label className="text-sm text-gray-400">To:</label>
          <input
            type="number"
            className="w-full bg-transparent text-white text-lg font-semibold focus:outline-none"
            placeholder="0.0"
            value={outputToken}
            onChange={(e) => setOutputToken(e.target.value)}
          />
        </div>

        <button className="w-full mt-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-white font-semibold text-lg">
          Swap
        </button>
      </div>
    </div>
  );
};

export default Swap;