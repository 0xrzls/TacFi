import React from "react";
import { Link } from "react-router-dom";
import { AiOutlineSwap, AiOutlineWallet } from "react-icons/ai";
import { MdOutlineWaterDrop } from "react-icons/md";

const Navbar = () => {
  return (
    <div className="fixed bottom-0 left-0 w-full bg-gray-900 p-3 flex justify-around border-t border-gray-700">
      <Link to="/" className="flex flex-col items-center text-white">
        <AiOutlineSwap className="text-2xl" />
        <span className="text-xs">Swap</span>
      </Link>
      <Link to="/liquidity" className="flex flex-col items-center text-white">
        <MdOutlineWaterDrop className="text-2xl" />
        <span className="text-xs">Liquidity</span>
      </Link>
      <Link to="/wallet" className="flex flex-col items-center text-white">
        <AiOutlineWallet className="text-2xl" />
        <span className="text-xs">Wallet</span>
      </Link>
    </div>
  );
};

export default Navbar;