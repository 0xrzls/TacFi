import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Swap from "./components/Swap";
import Navbar from "./components/Navbar";
import WalletConnect from "./components/WalletConnect";

function App() {
  return (
    <Router>
      <div className="pb-16">
        <div className="flex justify-end p-4">
          <WalletConnect />
        </div>
        <Routes>
          <Route path="/" element={<Swap />} />
        </Routes>
      </div>
      <Navbar />
    </Router>
  );
}

export default App;