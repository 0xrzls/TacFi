
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#4A90E2",
        background: "#121212",
        card: "#1E1E1E",
        text: "#FFFFFF",
      }
    },
  },
  plugins: [],
};
