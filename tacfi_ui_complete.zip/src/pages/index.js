
import React from "react";
import Header from "../components/Header";
import BottomNav from "../components/BottomNav";

export default function Home() {
  return (
    <div className="bg-background min-h-screen flex flex-col items-center text-text">
      <Header />

      <main className="flex-grow flex flex-col justify-center items-center">
        <div className="bg-card p-6 rounded-lg w-96">
          <h2 className="text-center text-xl mb-4">Swap</h2>
          <input type="text" placeholder="From" className="w-full p-2 mb-2 bg-gray-700 rounded" />
          <input type="text" placeholder="To" className="w-full p-2 bg-gray-700 rounded" />
          <button className="w-full mt-4 bg-primary p-2 rounded">Swap</button>
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
