
import React from "react";

export default function BottomNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card p-4 flex justify-around text-text">
      <button className="flex flex-col items-center">
        <span>🏠</span>
        <span>Home</span>
      </button>
      <button className="flex flex-col items-center">
        <span>🔄</span>
        <span>Swap</span>
      </button>
      <button className="flex flex-col items-center">
        <span>📊</span>
        <span>Pool</span>
      </button>
      <button className="flex flex-col items-center">
        <span>⚙️</span>
        <span>Settings</span>
      </button>
    </nav>
  );
}
